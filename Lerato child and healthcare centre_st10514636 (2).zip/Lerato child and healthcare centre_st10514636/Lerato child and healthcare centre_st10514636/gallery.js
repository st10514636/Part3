<!Doctype html>
<html lang="en">
<head>
    <title>Gallery</title>
     <link rel="stylesheet" href="style/css.css">
    <script src="Gallery.js" defer></script>
</head>
<body style="background-color: hotpink;">
    <header>
        <img src="images/logo.png" width="65px" height="50px">
        <nav>
            <a href="Home.html">Home</a>
            <a href="About us.html">About us</a>
            <a href="Gallery.html">Gallery</a>
            <a href="Testimonials.html">Testimonials</a>
            <a href="Contact us.html">Contact us</a>
            <a href="Donations.html">Donations</a>
        </nav>
    </header>
    <main>
        <h1><u>Lerato Child and youthcare centre</u></h1>
        <h2><u>Gallery</u></h2>
        <img src="images/1..jpg" width="250px" height="300px">
        <img src="images/5..jpg" width="250px" height="300px">
        <img src="images/3..jpg" width="250px" height="300px">
        <img src="images/4..jpg" width="250px" height="300px">
        <img src="images/2..jpg" width="250px" height="300px">
        <img src="images/6..jpg" width="250px" height="300px">
        <img src="images/7..jpg" width="250px" height="300px">
    </main>
    <footer></footer>
     <script>
        const images = document.querySelectorAll('.gallery-img');
        images.forEach(image => {
        image.addEventListener('click', () => {
        if (image.style.transform === "scale(1.5)") {
            image.style.transform = "scale(1)";
            image.style.zIndex = "1";
            image.style.boxShadow = "none";
        } else {
         images.forEach(img => {
        img.style.transform = "scale(1)";
        img.style.zIndex = "1";
        img.style.boxShadow = "none";
         });
        image.style.transform = "scale(1.5)";
        image.style.transition = "transform 0.3s ease";
        image.style.zIndex = "10";
        image.style.position= "relative";
        image.style.boxShadow = "0px 4px 15px black";
        }
    });
});
    </script>
</body>
</html>