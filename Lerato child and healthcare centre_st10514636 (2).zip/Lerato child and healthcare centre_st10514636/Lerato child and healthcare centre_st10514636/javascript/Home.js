<!doctype html>
<html lang="en">
<head>
    <title>home</title>
     <link rel="stylesheet" href="style/css.css">
    <script src="home.js" defer></script>
</head>
<body>
    <header>
        <img src="images/8.1.jpg" style="width: 65px;" height="50px">
        <nav aliign="centre">
            <a href="home.html">Home | </a>
            <a href="About us.html">About us |</a>
            <a href="Gallery.html">Gallery |</a>
            <a href="Testimonials.html">Products |</a>
            <a href="Contact us.html">Contact us|</a>
            <a href="Donations.html">Donations</a>
        </nav>
    </header>
    <main>
<h1 style="font-style: initial;"><u>Lerato Child and youthcare centre</u></h1>
<h2 style="font-style: inherit;"><u>Nurturing Futures,Changing lives</u></h2>
<img src="images/logo.png" width=500px" height="500px">
 <source src="images/lerato video.htm">

</video>
    </main>
    <footer>
        <a href="https://www.leratocycc.org.za/" target="_blank">Donate to Lerato Child and Youthcare Centre</a>
      &copy;st10514636
    </footer>
    <script>
        window.addEventListener('DOMContentLoaded';() => {
        const currentHour= new date().getHours();
        let greeting = "Welcome to Lerato child and youthcare centre!";
        if (currentHour < 12) {
        greeting = "Good morning!" + greeting;
        } else if (currentHour < 18) {
        greeting = "Good afternoon!" + greeting;
    } else {
        greeting = "Good evening!" + greeting;
        }
        alert(greeting);
        });
        const donationLink = document.querySelector('footer a');
        if (donationLink) {
        donationLink.addEventListener('click' , () => {
        alert("Thank you for opening our donation page and supporting the children");
        });
    }
    </script>
</body>
</html>
