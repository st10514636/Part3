<!Doctype html>
<html lang="en">
    <head>
        <title>About</title>
    </head>
    <body style="background-color: lightcoral;">
        <header>
            <img src="images/logo.png">
            <nav>
                <a href="Home.html">Home</a>
                <a href="About us.html">About us</a>
                <a href="Gallery.html">Gallery</a>
                <a href="Testimonials.html">Testimonials</a>
                <a href="Contact us.html">Contact us</a>
                <a href="Donations.html">Donations</a>
            </nav>
        </header>
        <main>
            <h1 align="centre"><u>Lerato child and youthcare centre</u></h1>
            <p>Lerato child and youth care centre is dedicated to providing a safe,nurturing environment for children and youth in need.Our team works tirelessly to offer support, care,and opportunities for growth, helping young lives flourish.</p>
            <p><u style="color: darkviolet;">OUR MISSION </u>: To empower and nurture children and youth to reach their full potential.</p>
            <p><u style="color: darkviolet;">OUR IMPACT</u>: Creating positive change in the community, one young life at a time.</p>
            <p><u style="color: darkviolet;">VALUES</u>:Their operations are guided by the "DELIGHT" values e.g Development,Empathy,Love,Integrity,Growth,Hope and Transparency</p>
            <p><u style="color: darkviolet;">OPERATIONAL SUPPORT</u>:The centre heavily depends on public donations,corporate social investment,and partnerships to cover essentials like food,staff salaries,and utility costs.</p>
            <p><u>TEAM PROFILES</u></p>
            <img src="images/7..jpg">
            <table border="1">
                <tr>
                    <th>NAME</th><th>OCCUPATION</th><th></th>
                    </tr>
                    <tr>
                <th>Kotie</th><th>Centre Manager</th> <th>operations and oversees the residential facility.</th>
                </tr>
                <th>Suanne de Bruyn-Leeuwner</th><th>Social Worker</th><th>Leads the thrapeutic and social support for children.</li>
                    <tr>
                <th>Joaline Calitz,Katelynn Pienaar,and others</th><th>Child and Youthcare Workers(CYCWs)</th><th>provide daily care,comfort,and supervision</th>
                </tr>
                <tr>
                    <th></th><th>Board Members</th><th>Work behind the scenes to support the centres mission</th>
                </tr>
        </table>
        <h2><u>WE MEASURE OUR WORK BECAUSE EVERY CHILD MATTERS:</u></h2>
        <Ul>
            <li><u>Child welfare</u>:32 children aged 0-18 in our care, with space of 40</li>
            <li><u>Education</u>:95% + school attendance.All school-age children enrolled.</li>
            <li><u>Health</u>:Daily meals,clinic check-ups,and play therapy for children who need it.</li>
            <li><u>Family</u>:6 children reunited with safe family members in 2024</li>
            <li><u>Governance</u>:Registered NPO,Clean annual audits,Staff ratios meet DSD norms</li>
        </Ul>
        </main>
        <script>
            const triggers = document.querySelectorAll('.mission-trigger');
            triggers.forEach(trigger => {
            trigger.addEventListener('clock', (e) => {
            const title = e.target.innerText;
            alert('Thank you for reading about our ${title}! We appreciate your interest in Lerato Child and Youth Care Centre');
            });
        });
        const rows = document.querySelectorAll('table tbody tr');
        rows.forEach(row => {
        row.addEventListener('mouseenter' , () => {
        row.style.backgroundColor = 'lightyellow';
        });
        row.addEventListener('mouseleave', () => {
        row.style.backgroundColor = 'white';
        });
    });
        </script>
    </body>
</html>