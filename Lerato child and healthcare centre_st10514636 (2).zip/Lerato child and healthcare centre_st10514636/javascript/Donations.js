<!Doctype html>
<html>
    <head>
        <title>Donations</title>
         <link rel="stylesheet" href="style/css.css">
    <script src="Donations.js" defer></script>
    </head>
    <body style="background-color: lightcoral;">
        <header>
            <img src="images/logo.png">
            <nav>
                <a href="Home.html">Home</a>
                <a href="About us.html">About us</a>
                <a href="Gallery.html">Gallery</a>
                <a href="Testimonials.html">Testimonials</a>
                <a href="Contact us.html">Contact us</a>
                <a href="Donations.html">Donations</a>
            </nav>
            <header></header>
            <main>
                <h1 style="font-size: large;"><u>WHERE YOUR DONATION GOES:</u></h1>
                <Ul>
                    <li>R150 feeds one child for a week:3 nutritious meals and 2 snacks daily.</li>
                    <li>R500 covers school transport for one child for a month so they never miss class</li>
                    <li>R1,200 funds one play therapy session to help a child heal from trauma</li>
                    <li>R3,000 buys a full school starter pack:uniform,shoes,stationery,and backpack.</li>
                    <li>Montly donation:Helps us plan.70% of every rand goes directly to child care,Education,and health.</li>
                </Ul>
                <h2 style="font-size: larger;"><u>HOW TO DONATE</u></h2>
                <h3 style="font-size: larger;"><u>EFT/BANK DEPOSIT:</u></h3>
                <ul>
                    <li>ACCOUNT:Lerato Child and Youthcare Centre</li>
                    <li>BANK:First National Bank (FNB)</li>
                    <li>ACCOUNT NO.:62012345678</li>
                    <li>BRANCH CODE:250655</li>
                    <li>ACCOUNT TYPE:Cheque Account</li>
                    <li>REFERENCE:Your name+Donation</li>
                    <li>NPO No:037-123 NPO</li>
                </ul>
            </main> 
            <footer>
                <a href="https://www.leratocycc.org.za/" target="_blank">DONATE NOW</a>
            </footer>
             <script>
                function  handleDonation (event) {
                    event.preventDefault() ;
                    var name= document.getElementById('fullName'). value;
                    var email= document.getElementById('email').value;
                    var amount=document.getElementById ('amount').value
                    var bankName= document.getElementById ('donorBank')
                    var accNumber= document.getElementById ('donorAccount') . value;
                     document.getElementById('donorName').innerText= name;
                     document.getElementById('pledgeAmount').innerText=amount;
                     document.getElementById('donorEmail').innerText=email;
                     document.getElementById('donorBankDisplay').innerText=bankName;
                     document.getElementById('donorAccDisplay').innerText =accNumber.slice(-4);
                     document.getElementById('thankYouMessage').style.display= 'block';
                     document.getElementById(donationForm).reset();
                }
            </script>
            </body>
            </html>