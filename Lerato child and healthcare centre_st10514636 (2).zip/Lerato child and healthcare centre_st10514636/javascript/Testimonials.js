<!Doctype html> 
<html>
    <head>
        <title>Testimonials</title>
         <link rel="stylesheet" href="style/css.css">
    <script src="Testimonials.js" defer></script>
    </head>
    <body style="background-color: yellow;">
    <header>
        <img src="images/logo.png">
        <nav>
            <a href="Home.html">Home</a>
            <a href="About us.html">About us</a>
            <a href="Gallery.html">Gallery</a>
            <a href="Testimonials.html">Testimonials</a>
            <a href="Contact us.html">Contact us</a>
            <a href="Donations.html">Donations</a>
        </nav>
    </header>
    <main>
        <h1 align="centre" style="font-style: initial;"><u>Key testimonials</u></h1>
        <ul>
            <li><u>Community Engagement</u>: Local businesses like Panarottis and JAM Clothing (Riverstone mall) frequently visit, bringing food, gifts, and donations for the kids.</li>
            <li><u>Dedicated care and transformation</u>:The Lerato cycc employees are praised as superheroes for going above and beyond to give kids love,protection and support.</li>
            <li><u>Healing and development</u>:Within a few weeks of arrival,kids who were severely malnourished showed improvements in their overall weight,health and socialization skills.</li>
            <li><u>Safe Haven and community support</u>:Local partners,such as Riverstone mall,recognizes the centres contributions to the Kookrus community and often provide the kids with entertaining events and donations</li>
            <li><u>Emphasis on childrens needs</u>:The facility provides a safe,family-oriented environment designed to protect kids from further abuse.</li>
        </ul>
        <h2 style="font-size: large;"><u style="color: deeppink;">FROM OLDER YOUTH</u></h2>
        <p>"Lerato was the first place I felt safe.The housemothers helped me with homework every night.I passed matric and now I'm studying to be a social worker."-Thabo,19,lived at Lerato for 6 years</p>
        <p>"I learnt how to budget and cook at Lerato.When i moved out at 18,I wasnt scared.They still check on me."-Naledi,20,care-leaver</p>
        <h3 style="font-size: large;"><u style="color: deeppink;">FROM SCHOOL/COMMUNITY PARTNERS</u></h3>
        <p>"Lerato children arrive on time,in clean uniform,ready to learn.You can see they are cared for.Attendance is excellent."-Mrs Mokoena,Grade 6 Teacher,Meyerton Primary</p>
       <p>"We've worked with Lerato for 5 years.They communicate well,keep clinic cards updated,and always put the child first."-Sr. Dlamini,Clinic Sister,Meyerton Clinic</p>
       <h4 style="font-size: large;"><u style="color: deeppink;">FROM VOLUNTUEERS/DONORS</u></h4>
       <p>"I tutor maths every Tuesday.The kids are bright and respectful.The staff make it easy to help-they're organised and tell you exactly whats needed."-James,Volunteer Tutor</p>
       <p>"I donate monthly because Lerato sends a short update once a year showing where the money went.32 kids fed,0 safety incidents.That's accountability."-Sarah K,monthly donor</p>
       <h5 style="font-size: large;"><u style="color: deeppink;">SOCIAL WORKER</u></h5>
       <p>"Lerato CYCC maintains full compliance with DSD norms.Staff-to-child ratios are met,records are up to date,and reunification plans are actively pursued.They are a trusted placement."-Social worker,DSD Sedibeng</p>
    </main>
   <footer></footer>
   <script>
    window.onload = function() {
    console.log("Testimonials interactive features loaded!");
    const quotes = document.querySelectorAll("testimonial-quote");
    quotes.style.cursor = "pointer";
    quotes.style.padding = "6px";
    quotes.style.borderRadius = " 4px";
    quotes.style.transition = "background-color 0.3s ease, font-weight 0.2s ease";
    quote.addEventListener("click", function() {
    if (this.style.backgroundColor === "white") {
        this.backgroundColor = "";
        this.style.fontWeight = "normal";
        this.style.boxShadow = "none";
    } else {
        quotes.forEach(q=> {
        q.style.backgroundColor = "";
        q.style.fontWeight = "normal";
        q.style.boxShadow = "none";
        });
        this.style.backgroundColor = "white";
        this.style.fontWeight = "bold";
        this.style.boxShadow ="0PX 2PX 6PX rgba(0,0,0,0.15)";
    }
});
});
};
   </script>
    </body>
</html>