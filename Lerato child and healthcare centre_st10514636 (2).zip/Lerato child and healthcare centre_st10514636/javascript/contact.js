<!doctype html>
<html>
<head>
    <title>Contact</title>
    <link rel="stylesheet" href="style/css.css">
    <script src="Contact.js" defer></script>
</head>
<body style="background-color: yellow;">
    <header>
        <img src="images/8.1.jpg" alt="logo" style="width: 350px;" height="150px">
        <nav aliign="centre">
            <a href="home.html">Home | </a>
            <a href="About us.html">About us |</a>
            <a href="Gallery.html">Gallery |</a>
            <a href="Testimonials.html">Products |</a>
            <a href="Contact us.html">Contact us|</a>
            <a href="Donations.html">Donations</a>
        </nav>
    </header>
    <main>
      <h1 align="centre"><u>LERATO CHILD AND YOUTHCARE CENTRE</u></h1>  
      <h2><u> CONTACT US</u></h2>
<table border="1">
    <tr>
        <th>NAME</th><th>OCCUPATION</th><th>NUMBER</th>
    </tr>
    <tr>
    <th>KOTIE</th><th>MANAGER</th><th>0835948133</th>
    </tr>
    <tr>
        <th>SUANNE DE BRUYN-LEEUWNER</th><th>SOCIAL WORKER</th><th>0730070245</th>
    </tr>
    <tr>
        <th>-</th><th>ADMIN</th><th>0742729344</th>
    </tr>
    <tr>
        <th>-</th><th>HOUSE PHONE</th><th>0731495483</th>
    </tr>
</table>
<h3><u>EMAIL</u>:info@leratocycc.org.za</h3>
<h4 style="font-size: large;"><u style="color: purple;">ALTERNATIVE EMAIL(for applications)</u>:Leratocycc@outlook.com</h4>
<h5 style="font-size: large;"><u style="color: purple;">FACEBOOK PAGE</u>:https://www.facebook.com/leratocycc/</h5>
    </main>
    <footer>
        <h6 style="font-size: large;"><u>LOCATION:</u></h6>
        <iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d228807.05091613598!2d27.76083865534623!3d-26.355298407252402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e6!4m3!3m2!1d-26.194739199999997!2d28.0068096!4m5!1s0x1e94533a896aa131%3A0x8380d718575ceddd!2sLerato%20Day%20Care%20Center%2C%20Ext7%2C%2012604%20Daffodil%20St%2C%20Evaton%20West%2C%20Evaton%2C%201984!3m2!1d-26.512551199999997!2d27.8227741!5e0!3m2!1sen!2sza!4v1776247706637!5m2!1sen!2sza" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      &copy;st10514636
    </footer>
    <script>
        window.onload = function () {
        console.log("Contact page javascript loaded successfully");
        let today = new Date();
        let hour =today.hetHours();
        let greeting = "";
        if (hour < 12) {
            greeting = "Good morning! Welcome to Lerato Child and Youthcare Centre.";
        } else if (hour < 18) {
         greeting = "Good afternoon! Welcome to Lerato Child and Youthcare Centre.";
        } else }
         greeting= "Good evening! Welcome to Lerato Child and Youthcare Centre.";
    }
    alert(greeting);
    let tableRows = document.querySelectorAll("table tr");
    for (let i=1; i < tableRows.length; i++) {
    tableRows[i].onmouseover = function() {
        this.style.backgroundColor = "white";
    };
}
};
    </script>
</body>
</html>
